from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from .models import Profile

def user_login(request):
    context = {}
    try:
        user = User.objects.get(username = request.user) 
        return HttpResponseRedirect(reverse('home'))

    except:
        if request.method=="POST":
            username=request.POST['username']
            password=request.POST['password']
            user = authenticate(request, username = username, password = password)
            if user:
                login(request,user)
                if request.GET.get('next',None):
                    return HttpResponseRedirect(request.GET['next'])
                return render(request,'success.html')
            else:
                context["error"] = "Please provide valid Credentials"
                return render(request,'auth/login.html',context)
        else:
            return render(request,"auth/login.html",context)

def user_logout(request):
    if request.method=="POST":
        logout(request)
        return HttpResponseRedirect(reverse('login'))

@login_required(login_url="/employee/login/")
def success(request):
        context={}
        u = User.objects.get(username=request.user)
        user_type = u.profile.type
        context['login_user_name'] = u.first_name + ' ' + u.last_name
    
        if user_type == 'L1':
            return HttpResponseRedirect(reverse('L2Home'))

        if user_type == 'L2':
            return HttpResponseRedirect(reverse('L2Home'))
